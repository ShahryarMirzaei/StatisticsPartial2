source("util.R")
# testMean 
# testVariance 
# testProportion added 

