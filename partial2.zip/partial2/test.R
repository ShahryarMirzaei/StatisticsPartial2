# descrete Rabndom var 

# Bernouli 
dbinom(4,10,0.5) # P(x=4) B(10, 0.5)
pbinom(2,10,0.5) # P(x<2) B(10,0.5)
pbinom(2,10,0.5) # creates the numbers 

dbinom(2,10,0.7) # 2 success in 10 time with success prob at 0.7
pbinom(4,10,0.7)
dbinom(3,10,0.17) # slide 20 I got different things 

# geometric distibution 
# n failed bernouli to ghet the first success
dgeom(5,3/75) # pay attention this is 5 failures and the 6th pass
# pgeom 
# qgeom : quantile, specify the value at that quantile 

# poisson distribution 
dpois(5,4) # 5 is the expected4 is the average, exactly 5 expectations 
ppois(1,4) # 1 or less addmissions, or ( fewer than 2 addmissions)
1-ppois(1,4)# more than one addmision a day, use minus 1 

# continuos random variable
#1: uniform ditribution
dunif(5,0,15) # the value at any point 
# slide 17 : interval 0 15 , wait time between 5 to 10
punif(10,0,15) - punif(5,0,15) # punif less that that

# normal distrubution 
pnorm(70, mean = 60, sd = 10) # X < q, for x>q use 1-pnorm 
pnorm(80,60,10) # x <80
1- pnorm(46,60,10) # 1- as we want greater than 
# between a and b 
pnorm(80,60,10)-pnorm(39,60,10) # between 2 nums 

# in slide 31 ? 
# left chisq and fisgher and T disributions 
 


