# basic utility functions 
sampleVar <- function(data){
  return (var(data))
}
sampleSTd <- function(data){
  return(sd(data))
}
popVar <- function(data){
  n <- length(data)
  return (var(data)*(n-1)/n)
}
popSTd <- function(data){
  n <- length(data)
  return (sd(data)*(n-1)/n)
}

#-------------------------------

binomExact <- function(n, p , k){
  # binomExact(times, p of win, expected)
  return(dbinom(k,n,p))
}
binomLessThanEqual <-function(n, p , k){
  # binomLessThan(times, p of win, expected)
  return(pbinom(k,n,p))
}
binomLessThan <- function(n, p, k){
  # P(X < k) = P(X <= k-1)
  return(pbinom(k - 1, size = n, prob = p))
}

# P(X > k)
binomMoreThan <- function(n, p, k){
  # P(X > k) = 1 - P(X <= k)
  return(1 - pbinom(k, size = n, prob = p))
}
binomExact(10,0.17,3)#0.1599833 5.20

geomExact <- function(p, k){
  # geomExact(p of win, trial_number)
  # P(First success is exactly on trial k)
  if (k <= 0) {
    return(0)
  }
  return(dgeom(k - 1, prob = p))
}

geomLessThanEqual <- function(p, k){
  # geomLessThan(p of win, trial_number)
  #  P(First success is on or before trial k) = P(X <= k)
  return(pgeom(k - 1, prob = p))
}
# P(X < x)
geomLessThan_Failures <- function(p, x){
  # P(X < x) = P(X <= x-1)
  # Probability of less than x failures before the first success.
  return(pgeom(x - 1, prob = p))
}

# P(X > x)
geomMoreThan_Failures <- function(p, x){
  # P(X > x) = 1 - P(X <= x)
  # Probability of strictly more than x failures before the first success.
  return(1 - pgeom(x, prob = p))
}

# poisson 
poisExact <- function(lambda, k){
  # poisExact(lambda, expected_count)
  # Calculates the probability of getting exactly k events.
  return(dpois(k, lambda = lambda))
}
poisLessThanEqual <-function(lambda, k){
  # poisLessThanEqual(lambda, expected_count)
  # Calculates the probability of getting k or fewer events.
  return(ppois(k, lambda = lambda))
}
poisLessThan <- function(lambda, k){
  # P(X<k)
  return(poisLessThanEqual(lambda,k)-poisExact(lambda,k))
}
poisMoreThan <- function(lambda,k){
  #P(x>k)
  return(1-poisLessThanEqual(lambda,k))
}
poisExact(4,5)
# fewwer than 2 admissions 
poisLessThan(4,2)
poisMoreThan(4,1)

#----------------------------------
#continuos from now 
# P(X<k) = P(X<=k)
#------------------------------
unifLessThanEqual <- function(a, b, k){
  # Calculates P(X <= k)
  return(punif(k, min = a, max = b))
}

unifLessThan <- function(a, b, k){
  # Calculates P(X < k) - Same as P(X <= k)
  return(punif(k, min = a, max = b))
}

# P(X > k)
unifMoreThan <- function(a, b, k){
  # Calculates P(X > k) = 1 - P(X <= k)
  return(1 - punif(k, min = a, max = b))
}
unifRangeInclusive <- function(a, b, x1, x2){
  # Calculates P(x1 <= X <= x2) = P(X <= x2) - P(X <= x1)
  # P(X <= x2)
  prob_up_to_x2 <- punif(x2, min = a, max = b)
  
  # P(X <= x1)
  prob_up_to_x1 <- punif(x1, min = a, max = b)
  
  return(prob_up_to_x2 - prob_up_to_x1)
}
unifRangeExclusive <- function(a, b, x1, x2){
  # Calculates P(x1 < X < x2) - Same as P(x1 <= X <= x2)
  return(unifRangeInclusive(a, b, x1, x2))
}
unifMean <- function(a, b){
  # Calculates the mean (expected value) E[X]
  return((a + b) / 2)
}

unifVariance <- function(a, b){
  # Calculates the variance Var[X]
  return(((b - a)^2) / 12)
}

#--------------------------------------------------------
#Normal distr 
#------------------------------------------------

normLessThanEqual <- function(mu, sigma, k){
  # Calculates P(X <= k)
  return(pnorm(k, mean = mu, sd = sigma))
}
normLessThan <- function(mu, sigma, k){
  # Calculates P(X < k) - Same as P(X <= k)
  return(pnorm(k, mean = mu, sd = sigma))
}

# P(X > k)
normMoreThan <- function(mu, sigma, k){
  # Calculates P(X > k) = 1 - P(X <= k)
  return(1 - pnorm(k, mean = mu, sd = sigma))
}

# P(x1 <= X <= x2) and P(x1 < X < x2) - Identical for Continuous Distributions
normRangeInclusive <- function(mu, sigma, x1, x2){
  # Calculates P(x1 <= X <= x2) = P(X <= x2) - P(X <= x1)
  
  if (x1 > x2) {
    return(0)
  }
  
  # P(X <= x2)
  prob_up_to_x2 <- pnorm(x2, mean = mu, sd = sigma)
  
  # P(X <= x1)
  prob_up_to_x1 <- pnorm(x1, mean = mu, sd = sigma)
  
  return(prob_up_to_x2 - prob_up_to_x1)
}

normRangeExclusive <- function(mu, sigma, x1, x2){
  # Calculates P(x1 < X < x2) - Same as P(x1 <= X <= x2)
  return(normRangeInclusive(mu, sigma, x1, x2))
}
normMean <- function(mu, sigma){
  # Calculates the mean (expected value) E[X]
  return(mu)
}

normVariance <- function(mu, sigma){
  # Calculates the variance Var[X]
  # Note: The input parameter is conventionally the standard deviation (sigma)
  return(sigma^2)
}

#-------------------------------------------
# in case of normalized use functions with
# mu = 0, sigma = 1 , Z = (x_mu)/sigma
#---------------------------------------------
normLessThan(6,1.5,5) # check this, here I got a different result 

# critical value and alpha 
# tail: A string indicating the tail ("upper" for P(X > k) = alpha, 
#       "lower" for P(X < k) = alpha). Defaults to "upper".



#-------------------------- 
# approximations : 
# use the function to get the correct values 
# -----------------------------

continuityCorrection <- function(type, lower_bound, upper_bound = NULL) {
  # Convert bounds to numeric, ensuring proper handling of NA if upper_bound is not provided
  a <- as.numeric(lower_bound)
  b <- as.numeric(upper_bound)
  
  # Input validation
  if (is.na(a)) {
    stop("lower_bound 'a' must be provided.")
  }
  
  correction_result <- switch(type,
                              "=" = {
                                # For P(X = a) -> P(a - 0.5 <= Y <= a + 0.5)
                                if (!is.null(upper_bound) && !is.na(b)) {
                                  warning("upper_bound 'b' is ignored for type '='.")
                                }
                                sprintf("P(%.1f <= Y <= %.1f)", a - 0.5, a + 0.5)
                              },
                              "<" = {
                                # For P(a < X < b) -> P(a + 0.5 <= Y <= b - 0.5)
                                # This case also covers P(X < b) if a is effectively -Inf
                                if (is.na(b)) {
                                  # P(X < b) is equivalent to P(X <= b - 1). Using P(a < X < b) where a is -Inf.
                                  # The correction for P(X < b) is P(Y <= b - 0.5)
                                  sprintf("P(Y <= %.1f)", a + 0.5) # This should be P(Y <= b-0.5) but b is NA here.
                                  # Given the slide's format, it's safer to stick to two-sided intervals for general use.
                                  # We will enforce both bounds for '<' and '<=' types for simplicity as per the slide.
                                  stop("upper_bound 'b' must be provided for type '<' (P(a < X < b)).")
                                }
                                sprintf("P(%.1f <= Y <= %.1f)", a + 0.5, b - 0.5)
                              },
                              "<=" = {
                                # The slide shows two entries for P(a <= X <= b):
                                # P(a <= X <= b) -> P(a - 0.5 <= Y <= b + 0.5)
                                # P(a <= X < b) -> P(a - 0.5 <= Y <= b - 0.5)
                                # P(a < X <= b) -> P(a + 0.5 <= Y <= b + 0.5)
                                
                                # To cover all three, we'll use a string for the right inequality type
                                # We'll default to the most general P(a <= X <= b) correction
                                stop("For P(a <= X <= b), use type 'less_equal_both' or specific types for one-sided boundaries (e.g., P(X <= b) -> P(Y <= b + 0.5)).")
                                # For the purpose of STRICTLY adhering to the two P(a <= X <= b) entries on the slide,
                                # let's assume the user will input one of the specific single inequality forms or use separate functions.
                              },
                              "less_equal_both" = {
                                # P(a <= X <= b) -> P(a - 0.5 <= Y <= b + 0.5)
                                if (is.na(b)) {
                                  stop("upper_bound 'b' must be provided for type 'less_equal_both' (P(a <= X <= b)).")
                                }
                                sprintf("P(%.1f <= Y <= %.1f)", a - 0.5, b + 0.5)
                              },
                              "less_equal_right" = {
                                # P(a < X <= b) -> P(a + 0.5 <= Y <= b + 0.5)
                                if (is.na(b)) {
                                  stop("upper_bound 'b' must be provided for type 'less_equal_right' (P(a < X <= b)).")
                                }
                                sprintf("P(%.1f <= Y <= %.1f)", a + 0.5, b + 0.5)
                              },
                              "less_equal_left" = {
                                # P(a <= X < b) -> P(a - 0.5 <= Y <= b - 0.5)
                                if (is.na(b)) {
                                  stop("upper_bound 'b' must be provided for type 'less_equal_left' (P(a <= X < b)).")
                                }
                                sprintf("P(%.1f <= Y <= %.1f)", a - 0.5, b - 0.5)
                              },
                              # Default case for invalid 'type'
                              stop("Invalid 'type'. Must be one of: '=', '<', 'less_equal_both', 'less_equal_right', or 'less_equal_left'.")
  )
  
  return(correction_result)
}

#----------------------------------
# Chi-Squared 
#-----------------------------------

chisqLessThanEqual <- function(df, k){
  # Calculates P(X <= k)
  return(pchisq(k, df = df))
}

chisqLessThan <- function(df, k){
  # Calculates P(X < k) - Same as P(X <= k)
  return(pchisq(k, df = df))
}

# P(X > k)
chisqMoreThan <- function(df, k){
  # Calculates P(X > k) = 1 - P(X <= k). This is often the P-value in tests.
  return(1 - pchisq(k, df = df))
}

# P(x1 <= X <= x2) and P(x1 < X < x2) - Identical for Continuous Distributions
chisqRangeInclusive <- function(df, x1, x2){
  # Calculates P(x1 <= X <= x2) = P(X <= x2) - P(X <= x1)
  
  if (x1 > x2) {
    return(0)
  }
  
  # P(X <= x2)
  prob_up_to_x2 <- pchisq(x2, df = df)
  
  # P(X <= x1)
  prob_up_to_x1 <- pchisq(x1, df = df)
  
  return(prob_up_to_x2 - prob_up_to_x1)
}

chisqRangeExclusive <- function(df, x1, x2){
  # Calculates P(x1 < X < x2) - Same as P(x1 <= X <= x2)
  return(chisqRangeInclusive(df, x1, x2))
}
chisqMean <- function(df){
  # Calculates the mean E[X]
  return(df)
}

chisqVariance <- function(df){
  # Calculates the variance Var[X]
  return(2 * df)
}

# 
# 
# 
# P(X <= k) or P(X < k)
tLessThanEqual <- function(df, k){
  # Calculates P(X <= k)
  return(pt(k, df = df))
}

# P(X > k)
tMoreThan <- function(df, k){
  # Calculates P(X > k) = 1 - P(X <= k)
  return(1 - pt(k, df = df))
}

# P(x1 <= X <= x2)
tRangeInclusive <- function(df, x1, x2){
  # Calculates P(x1 <= X <= x2) = P(X <= x2) - P(X <= x1)
  
  if (x1 > x2) {
    return(0)
  }
  return(pt(x2, df = df) - pt(x1, df = df))
}

# Mean and Variance
# Note: Mean is 0 if df > 1. Variance is df/(df-2) if df > 2.
tMean <- function(df){
  if (df > 1) {
    return(0)
  } else {
    return(NaN) # Undefined for df <= 1
  }
}

tVariance <- function(df){
  if (df > 2) {
    return(df / (df - 2))
  } else if (df > 0 && df <= 2) {
    return(Inf) # Infinite for 1 < df <= 2
  } else {
    return(NaN) # Undefined for df <= 0
  }
}

# 
# 
# 

# P(X <= k) or P(X < k)
fLessThanEqual <- function(df1, df2, k){
  # Calculates P(X <= k)
  return(pf(k, df1 = df1, df2 = df2))
}

# P(X > k)
fMoreThan <- function(df1, df2, k){
  # Calculates P(X > k) = 1 - P(X <= k). This is often the P-value in ANOVA.
  return(1 - pf(k, df1 = df1, df2 = df2))
}

# P(x1 <= X <= x2)
fRangeInclusive <- function(df1, df2, x1, x2){
  # Calculates P(x1 <= X <= x2) = P(X <= x2) - P(X <= x1)
  
  if (x1 > x2) {
    return(0)
  }
  
  prob_up_to_x2 <- pf(x2, df1 = df1, df2 = df2)
  prob_up_to_x1 <- pf(x1, df1 = df1, df2 = df2)
  
  return(prob_up_to_x2 - prob_up_to_x1)
}

# Mean and Variance
# Note: Mean is df2/(df2-2) if df2 > 2.

fMean <- function(df1, df2){
  if (df2 > 2) {
    return(df2 / (df2 - 2))
  } else {
    return(NaN) # Undefined for df2 <= 2
  }
}

fVariance <- function(df1, df2){
  if (df2 > 4) {
    numerator <- 2 * df2^2 * (df1 + df2 - 2)
    denominator <- df1 * (df2 - 2)^2 * (df2 - 4)
    return(numerator / denominator)
  } else {
    return(NaN) # Undefined for df2 <= 4
  }
}


############################### 
########################################
###### chapter6
#############################
########################


# distributions 
# 1. Mean : variance YES, n>=30
normSE <- function(sigma, n){
  # SE = σ / sqrt(n)
  return(sigma / sqrt(n))
}

normZStatistic <- function(x_bar, mu, sigma, n){
  # Z = (X̄ - μ) / SE
  se <- normSE(sigma, n)
  return((x_bar - mu) / se)
}

criticalZValue <- function(alpha){
  # Returns the positive Z-score (z_crit) for a two-tailed test, 
  # where P(|Z| > z_crit) = alpha.
  # Use the Standard Normal Distribution (mu=0, sigma=1)
  return(qnorm(1 - alpha/2, mean = 0, sd = 1))
}

# Mean: var NO n<30: usign tDist with n-1 df 

tEstSE <- function(S, n){
  # Est. SE = S / sqrt(n)
  return(S / sqrt(n))
}

# 2. Calculates the T-Statistic
tStatistic <- function(x_bar, mu, S, n){
  # t = (X̄ - μ) / Est. SE
  est_se <- tEstSE(S, n)
  return((x_bar - mu) / est_se)
}
# the exercise at 17 ?
denom <- tEstSE(10.85,16)
t1 <- 8/denom
tRangeInclusive(15,-t1,t1)

#########3
## also other distributions : I left them 
###########3

#-----------------------------
# confidence intervals 
#-----------------------------
intervalMean <- function(x_bar, n, alpha, sigma = NULL, S = NULL) {
  
  # --- Input Validation ---
  if (is.null(sigma) && is.null(S)) {
    stop("Error: Must provide either the population standard deviation (sigma) or the sample standard deviation (S).")
  }
  
  conf_level <- 1 - alpha
  df <- n - 1
  
  # --- Determine Case ---
  
  # CASE 1: Population Variance KNOWN (Always Z-Interval)
  if (!is.null(sigma)) {
    
    # 1. Known Variance: I = [ X̄ ± z_α/2 * (σ / √n) ]
    
    # Standard Error (SE)
    se <- sigma / sqrt(n)
    
    # Critical Value (Z-score)
    crit_value <- qnorm(1 - alpha / 2) 
    method <- "Z-Interval (Sigma Known)"
    
  } 
  
  # CASE 2 & 3: Population Variance UNKNOWN (Use S)
  else if (!is.null(S)) {
    
    # Estimated Standard Error (Est. SE)
    se <- S / sqrt(n)
    
    # Sub-Case 2: Large Sample (n > 30) -> Z-approximation (from your image)
    if (n > 30) {
      crit_value <- qnorm(1 - alpha / 2) 
      method <- "Z-Interval (Sigma Unknown, n > 30)"
      
    } 
    
    # Sub-Case 3: Small Sample (n <= 30) -> T-Interval
    else {
      # 2. Unknown Variance, Small Sample: I = [ X̄ ± t_α/2, n-1 * (S / √n) ]
      crit_value <- qt(1 - alpha / 2, df = df)
      method <- paste0("T-Interval (Sigma Unknown, n <= 30, df=", df, ")")
    }
  }
  
  # --- Calculate Interval ---
  
  # Margin of Error (ME)
  me <- crit_value * se
  
  lower_bound <- x_bar - me
  upper_bound <- x_bar + me
  
  # --- Return Result ---
  result <- list(
    Method = method,
    Confidence_Level = conf_level,
    Sample_Mean = x_bar,
    Margin_of_Error = me,
    Interval = c(Lower = lower_bound, Upper = upper_bound)
  )
  
  return(result)
}
# Calculates the Confidence Interval for the Population Variance (σ^2).
# Parameters: S2 (Sample Variance S^2), n (Sample Size), alpha (Significance Level)
intervalVariance <- function(S2, n, alpha){
  df <- n - 1
  
  # 1. Find Critical Chi-Squared Values
  # Lower Critical Value (Area to the left = alpha/2)
  chisq_lower_crit <- qchisq(alpha / 2, df = df)
  
  # Upper Critical Value (Area to the left = 1 - alpha/2)
  chisq_upper_crit <- qchisq(1 - alpha / 2, df = df)
  
  # 2. Calculate Numerator (n-1) * S^2
  numerator <- df * S2
  
  # 3. Calculate Interval Bounds (Note the inversion in the denominator)
  # Lower Bound uses the Upper Critical Value:
  lower_bound <- numerator / chisq_upper_crit
  
  # Upper Bound uses the Lower Critical Value:
  upper_bound <- numerator / chisq_lower_crit
  
  return(c(Lower = lower_bound, Upper = upper_bound))
}

# Calculates the Confidence Interval for the Population Proportion (p).
# Parameters: p_hat (Sample Proportion), n (Sample Size), alpha (Significance Level)
intervalProportion <- function(p_hat, n, alpha){
  
  # 1. Calculate Estimated Standard Error of Proportion (Est. SE_phat)
  # This uses p_hat as the estimate for p in the SE formula.
  est_se_phat <- sqrt(p_hat * (1 - p_hat) / n)
  
  # 2. Find Critical Z-Value (z_alpha/2)
  # qnorm uses the area to the left, which is 1 - alpha/2.
  z_crit <- qnorm(1 - alpha / 2, mean = 0, sd = 1)
  
  # 3. Calculate Margin of Error (ME)
  me <- z_crit * est_se_phat
  
  # 4. Calculate Interval Bounds
  lower_bound <- p_hat - me
  upper_bound <- p_hat + me
  
  return(c(Lower = lower_bound, Upper = upper_bound))
}




# Attention: for mean intercval, the other that is NULL must input NULL 


####-----------------------------------
# confidence interval for 2 samples: 
# problem here 
###------------------------------------


# CI for the difference between 2 means 
intervalDiffMean <- function(x, y, conf_level = 0.95, equal_variance = FALSE) {
  
  # --- Perform the T-Test (the CI is a byproduct of the test) ---
  ci_results <- t.test(x, y, 
                       var.equal = equal_variance, 
                       conf.level = conf_level)
  
  # --- Extract Key Results ---
  
  # The confidence interval limits
  conf_interval <- ci_results$conf.int
  
  # The estimated difference in means
  mean_difference <- ci_results$estimate
  
  # --- Return Summary ---
  summary <- list(
    CI_Lower_Bound = as.numeric(conf_interval[1]),
    CI_Upper_Bound = as.numeric(conf_interval[2]),
    Mean_Difference_X_minus_Y = as.numeric(mean_difference[1] - mean_difference[2]),
    Confidence_Level = conf_level,
    Test_Type = ifelse(equal_variance, "Student's CI (Equal Variances Assumed)", 
                       "Welch's CI (Unequal Variances Assumed)")
  )
  
  return(summary)
}



 #interval, ratio of variance, normals
intervalRatioVariance <- function(S1_2, S2_2, n1, n2, alpha) {
  
  # --- Setup ---
  df1 <- n1 - 1 # Numerator degrees of freedom
  df2 <- n2 - 1 # Denominator degrees of freedom
  ratio_of_sample_variances <- S1_2 / S2_2
  conf_level <- 1 - alpha
  
  # 1. Find Critical F-Values
  
  # Lower Critical F-Value (F_1-alpha/2; df1, df2)
  # This corresponds to the area alpha/2 to the left (used in the upper bound)
  F_lower_crit <- qf(alpha / 2, df1 = df1, df2 = df2)
  
  # Upper Critical F-Value (F_alpha/2; df1, df2)
  # This corresponds to the area 1 - alpha/2 to the left (used in the lower bound)
  F_upper_crit <- qf(1 - alpha / 2, df1 = df1, df2 = df2)
  
  # 2. Calculate Interval Bounds (Note the inversion and flip in the denominator)
  
  # Lower Bound uses the Upper Critical F-Value:
  lower_bound <- ratio_of_sample_variances / F_upper_crit
  
  # Upper Bound uses the Lower Critical F-Value:
  upper_bound <- ratio_of_sample_variances / F_lower_crit
  
  # --- Return Result ---
  result <- list(
    Method = "F-Interval (Ratio of Variances)",
    Confidence_Level = conf_level,
    Sample_Variance_Ratio = ratio_of_sample_variances,
    Interval = c(Lower = lower_bound, Upper = upper_bound)
  )
  
  return(result)
}

intervalRatioVariance2 <- function(x, y, conf_level = 0.95) {
  
  # --- 1. Perform the F-Test (CI is included in output) ---
  ci_results <- var.test(x, y, conf.level = conf_level)
  
  # --- 2. Extract Key Results ---
  conf_interval <- ci_results$conf.int
  f_statistic <- ci_results$statistic
  
  # --- 3. Return Summary ---
  summary <- list(
    CI_Lower_Bound = as.numeric(conf_interval[1]),
    CI_Upper_Bound = as.numeric(conf_interval[2]),
    Confidence_Level = conf_level,
    Test_Statistic_F = as.numeric(f_statistic)
  )
  
  return(summary)
}
# interval, difference difference proportions +
intervalDiffProportion <- function(p_hat1, p_hat2, n1, n2, alpha) {
  
  # --- Setup ---
  diff_proportion <- p_hat1 - p_hat2
  conf_level <- 1 - alpha
  
  # 1. Calculate Standard Error of the Difference (SE_diff)
  term1_se <- (p_hat1 * (1 - p_hat1)) / n1
  term2_se <- (p_hat2 * (1 - p_hat2)) / n2
  se_diff <- sqrt(term1_se + term2_se)
  
  # 2. Find Critical Z-Value (z_alpha/2)
  crit_value <- qnorm(1 - alpha / 2, mean = 0, sd = 1)
  
  # 3. Calculate Margin of Error (ME)
  me <- crit_value * se_diff
  
  # 4. Calculate Interval Bounds
  lower_bound <- diff_proportion - me
  upper_bound <- diff_proportion + me
  
  # --- Return Result ---
  result <- list(
    Method = "Z-Interval (Difference of Proportions)",
    Confidence_Level = conf_level,
    Difference_of_Proportions = diff_proportion,
    Margin_of_Error = me,
    Interval = c(Lower = lower_bound, Upper = upper_bound)
  )
  
  return(result)
}
intervalDiffProportion2 <- function(x, n, conf_level = 0.95, correct = FALSE) {
  
  # Input validation
  if (length(x) != 2 || length(n) != 2) {
    stop("Both 'x' (successes) and 'n' (trials) must be vectors of length 2.")
  }
  
  # --- 1. Perform the Proportion Test (CI is included in output) ---
  ci_results <- prop.test(x = x, 
                          n = n, 
                          conf.level = conf_level,
                          correct = correct)
  
  # --- 2. Extract Key Results ---
  conf_interval <- ci_results$conf.int
  estimated_props <- x / n
  
  # --- 3. Return Summary ---
  summary <- list(
    CI_Lower_Bound = as.numeric(conf_interval[1]),
    CI_Upper_Bound = as.numeric(conf_interval[2]),
    Confidence_Level = conf_level,
    Estimated_P1 = estimated_props[1],
    Estimated_P2 = estimated_props[2],
    Difference_P1_minus_P2 = estimated_props[1] - estimated_props[2]
  )
  
  return(summary)
}

############################################
###Hypothesis Testing 
#######################################

# useful to have the utility functions and then use them 
zQuantile <- function(p) {
  return(qnorm(p))
}
tQuantile <- function(p, df) {
  return(qt(p, df = df))
}
fQuantile <- function(p, df1, df2) {
  return(qf(p, df1 = df1, df2 = df2))
}
chisqQuantile <- function(p, df) {
  return(qchisq(p, df = df))
}

# hypothese test for the variance 
testVariance <- function(s_squared, n, sigma0_squared, alpha = 0.05, alternative = c("less", "two.sided", "greater")) {
  
  # 1. Input Validation and Preparation
  alternative <- match.arg(alternative)
  
  # Degrees of freedom
  df <- n - 1
  
  # Check for valid inputs
  if (n < 2) stop("Sample size (n) must be at least 2 (degrees of freedom must be >= 1).")
  if (alpha <= 0 | alpha >= 1) stop("Alpha (significance level) must be between 0 and 1.")
  if (s_squared <= 0) stop("Sample variance (s^2) must be positive.")
  if (sigma0_squared <= 0) stop("Null variance (sigma0^2) must be positive.")
  
  # 2. Calculate Test Statistic
  # Test Statistic: (n-1)s^2 / sigma0^2
  test_statistic <- (df * s_squared) / sigma0_squared
  stat_label <- "Chi-squared"
  
  # 3. Calculate p-value and Critical Value(s)
  if (alternative == "less") {
    # H_a: sigma^2 < sigma0^2 (Left-tailed test)
    # Critical Region: X^2 < chi^2_{1-alpha, n-1}
    p_value <- pchisq(test_statistic, df = df, lower.tail = TRUE)
    critical_value_low <- qchisq(alpha, df = df)
    critical_value_high <- NA
    critical_label <- expression(paste(chi^2, "_{1-", alpha, ", n-1}"))
    
  } else if (alternative == "greater") {
    # H_a: sigma^2 > sigma0^2 (Right-tailed test)
    # Critical Region: X^2 > chi^2_{alpha, n-1}
    p_value <- pchisq(test_statistic, df = df, lower.tail = FALSE)
    critical_value_low <- NA
    critical_value_high <- qchisq(1 - alpha, df = df)
    critical_label <- expression(paste(chi^2, "_{", alpha, ", n-1}"))
    
  } else { # two.sided
    # H_a: sigma^2 != sigma0^2 (Two-tailed test)
    # Critical Region: X^2 not in [chi^2_{1-alpha/2, n-1}, chi^2_{alpha/2, n-1}]
    p_value <- 2 * min(pchisq(test_statistic, df = df, lower.tail = TRUE),
                       pchisq(test_statistic, df = df, lower.tail = FALSE))
    critical_value_low <- qchisq(alpha / 2, df = df)
    critical_value_high <- qchisq(1 - alpha / 2, df = df)
    critical_label <- expression(paste("[", chi^2, "_{1-", alpha/2, ", n-1}", ", ", chi^2, "_{", alpha/2, ", n-1}", "]"))
  }
  
  # 4. Decision Rule based on p-value
  if (p_value < alpha) {
    decision <- paste("Reject H0 (p-value < alpha)")
  } else {
    decision <- paste("Fail to Reject H0 (p-value >= alpha)")
  }
  
  # 5. Output Results (as a list)
  result <- list(
    test_type = "Chi-squared Test for Variance",
    alternative = alternative,
    null_variance = sigma0_squared,
    sample_variance = s_squared,
    sample_size = n,
    degrees_of_freedom = df,
    significance_level = alpha,
    test_statistic_value = test_statistic,
    test_statistic_label = stat_label,
    p_value = p_value,
    critical_value_low = critical_value_low,
    critical_value_high = critical_value_high,
    critical_label = critical_label,
    decision = decision
  )
  
  class(result) <- "htestVariance" # Assign a class for custom printing
  return(result)
}

# test for the proportion
testProportion <- function(x, n, p0, alpha = 0.05, alternative = c("less", "two.sided", "greater")) {
  
  # 1. Input Validation and Preparation
  alternative <- match.arg(alternative)
  
  # Sample proportion (p-hat)
  p_hat <- x / n
  
  # Check for valid inputs
  if (n < 1) stop("Sample size (n) must be at least 1.")
  if (x < 0 || x > n) stop("Number of successes (x) must be between 0 and n.")
  if (alpha <= 0 || alpha >= 1) stop("Alpha (significance level) must be between 0 and 1.")
  if (p0 <= 0 || p0 >= 1) warning("Null proportion (p0) is close to or outside (0, 1). Results may be unreliable.")
  
  # Check for Normal Approximation assumption (n*p >= 10 and n*(1-p) >= 10, typically using the NULL proportion)
  if (n * p0 < 10 || n * (1 - p0) < 10) {
    warning("Normal approximation condition (n*p0 >= 10 and n*(1-p0) >= 10) may not be met. Results might be unreliable.")
    # Note: For strict adherence to the critical region formula shown, the denominator uses p-hat, 
    # but the assumption check typically uses p0. We will proceed with the formula provided in the image.
  }
  
  # 2. Calculate Test Statistic
  # Test Statistic: (p-hat - p0) / sqrt( p-hat * (1 - p-hat) / n )
  # This formula uses the SAMPLE proportion (p-hat) in the denominator, which is an alternative 
  # approach (Wald interval-based test) compared to the standard Z-test which uses p0 (Score test).
  # We use the formula exactly as shown in the image.
  se_phat <- sqrt(p_hat * (1 - p_hat) / n)
  
  if (se_phat == 0) stop("Cannot calculate test statistic: Standard error is zero (p-hat is 0 or 1).")
  
  test_statistic <- (p_hat - p0) / se_phat
  stat_label <- "Z"
  
  # 3. Calculate p-value and Critical Value(s)
  if (alternative == "less") {
    # H_a: p < p0 (Left-tailed test)
    # Critical Region: Z < -z_alpha
    p_value <- pnorm(test_statistic, lower.tail = TRUE)
    critical_value <- qnorm(alpha)
    critical_label <- "-z_alpha"
    
  } else if (alternative == "greater") {
    # H_a: p > p0 (Right-tailed test)
    # Critical Region: Z > z_alpha
    p_value <- pnorm(test_statistic, lower.tail = FALSE)
    critical_value <- qnorm(1 - alpha)
    critical_label <- "z_alpha"
    
  } else { # two.sided
    # H_a: p != p0 (Two-tailed test)
    # Critical Region: |Z| > z_alpha/2
    p_value <- 2 * pnorm(abs(test_statistic), lower.tail = FALSE)
    critical_value <- qnorm(1 - alpha / 2)
    critical_label <- "z_alpha/2"
  }
  
  # 4. Decision Rule based on p-value
  if (p_value < alpha) {
    decision <- paste("Reject H0 (p-value < alpha)")
  } else {
    decision <- paste("Fail to Reject H0 (p-value >= alpha)")
  }
  
  # 5. Output Results
  result <- list(
    test_type = "Z-Test for Proportion (using p-hat in SE)",
    alternative = alternative,
    null_proportion = p0,
    sample_proportion = p_hat,
    num_successes = x,
    sample_size = n,
    significance_level = alpha,
    test_statistic_value = test_statistic,
    test_statistic_label = stat_label,
    p_value = p_value,
    critical_value = critical_value,
    critical_label = critical_label,
    decision = decision
  )
  
  class(result) <- "htestProportion"
  return(result)
}


# for the hypothesis we can use the native functions like t.test etc. 
# but zTest is not native
testMean <- function(x_bar, s, n, mu0, alpha = 0.05, alternative = c("less", "two.sided", "greater"), sigma = NULL) {
  
  # 1. Input Validation and Preparation
  alternative <- match.arg(alternative)
  
  # Check for valid inputs
  if (n < 2) stop("Sample size (n) must be at least 2.")
  if (alpha <= 0 | alpha >= 1) stop("Alpha (significance level) must be between 0 and 1.")
  if (s < 0) stop("Sample standard deviation (s) must be non-negative.")
  if (!is.null(sigma) && sigma <= 0) stop("Population standard deviation (sigma) must be positive when provided.")
  
  # 2. Determine Test Type and Calculate Test Statistic
  if (!is.null(sigma)) {
    # Case 1: Variance is Known (Z-test)
    test_type <- "Z-test (Variance Known)"
    # The image uses 'sigma' when variance is known
    test_statistic <- (x_bar - mu0) / (sigma / sqrt(n))
    df <- NULL # Degrees of freedom not applicable for Z-test
    
  } else if (n > 30) {
    # Case 2: Variance is Unknown, Big Sample (Approximate Z-test/Large sample T-test)
    test_type <- "Z-test approx. (Variance Unknown, n > 30)"
    # The image uses 's' when variance is unknown and n > 30
    test_statistic <- (x_bar - mu0) / (s / sqrt(n))
    df <- NULL
    
  } else {
    # Case 3: Variance is Unknown, Small Sample (T-test)
    test_type <- "T-test (Variance Unknown, n <= 30)"
    # The image uses 't' distribution with df = n-1 when variance is unknown and n <= 30
    test_statistic <- (x_bar - mu0) / (s / sqrt(n))
    df <- n - 1
  }
  
  # 3. Calculate p-value and Critical Value
  if (test_type == "T-test (Variance Unknown, n <= 30)") {
    # T-distribution calculations
    if (alternative == "less") {
      p_value <- pt(test_statistic, df = df)
      critical_value <- qt(alpha, df = df)
    } else if (alternative == "greater") {
      p_value <- pt(test_statistic, df = df, lower.tail = FALSE)
      critical_value <- qt(1 - alpha, df = df)
    } else { # two.sided
      p_value <- 2 * pt(abs(test_statistic), df = df, lower.tail = FALSE)
      critical_value <- qt(1 - alpha / 2, df = df)
    }
    critical_label <- paste0(ifelse(alternative == "less", "t", "|t|"), "_crit")
    stat_label <- "T"
  } else {
    # Z-distribution calculations (for known sigma or n > 30)
    if (alternative == "less") {
      p_value <- pnorm(test_statistic)
      critical_value <- qnorm(alpha)
    } else if (alternative == "greater") {
      p_value <- pnorm(test_statistic, lower.tail = FALSE)
      critical_value <- qnorm(1 - alpha)
    } else { # two.sided
      p_value <- 2 * pnorm(abs(test_statistic), lower.tail = FALSE)
      critical_value <- qnorm(1 - alpha / 2)
    }
    critical_label <- paste0(ifelse(alternative == "less", "z", "|z|"), "_crit")
    stat_label <- "Z"
  }
  
  # 4. Decision Rule based on p-value
  if (p_value < alpha) {
    decision <- paste("Reject H0 (p-value < alpha)")
  } else {
    decision <- paste("Fail to Reject H0 (p-value >= alpha)")
  }
  
  # 5. Output Results (as a list)
  result <- list(
    test_type = test_type,
    alternative = alternative,
    null_hypothesis_mean = mu0,
    significance_level = alpha,
    sample_mean = x_bar,
    sample_sd = s,
    sample_size = n,
    test_statistic_value = test_statistic,
    test_statistic_label = stat_label,
    p_value = p_value,
    critical_value = critical_value,
    critical_value_label = critical_label,
    decision = decision
  )
  
  class(result) <- "htestMeanSummary" # Assign a class for custom printing
  return(result)
}


testStatiticVarianceChisq <- function(s_squared, sigma0_squared, n) {
  # Input validation
  if (n <= 1) {
    stop("Sample size 'n' must be greater than 1 for variance calculations.")
  }
  if (s_squared < 0 || sigma0_squared <= 0) {
    stop("Variance values (s^2 and sigma0^2) must be non-negative, and sigma0^2 must be positive.")
  }
  
  # Calculate the test statistic: (n-1) * s^2 / sigma_0^2
  test_statistic <- ((n - 1) * s_squared) / sigma0_squared
  
  return(test_statistic)
}

# Hypothesis test for variance 
varianceCriticalRegionTest <- function(chi2_stat, n, alpha, alternative = "two.sided") {
  
  df <- n - 1
  
  if (alternative == "less") {
    # H0: sigma^2 >= sigma0^2, Reject if: chi^2_stat < chi^2_{1-alpha, n-1}
    # Critical Value: Chi-squared at the (1-alpha) percentile
    # R function: qchisq(probability, df)
    crit_val <- qchisq(1 - alpha, df = df) 
    
    if (chi2_stat < crit_val) {
      return("Reject H0 (Test Statistic < Critical Value)")
    } else {
      return("Fail to Reject H0")
    }
    
  } else if (alternative == "greater") {
    # H0: sigma^2 <= sigma0^2, Reject if: chi^2_stat > chi^2_{alpha, n-1}
    # Critical Value: Chi-squared at the (alpha) percentile, calculated as right tail
    # R function: qchisq(alpha, df, lower.tail = FALSE)
    crit_val <- qchisq(alpha, df = df, lower.tail = FALSE)
    
    if (chi2_stat > crit_val) {
      return("Reject H0 (Test Statistic > Critical Value)")
    } else {
      return("Fail to Reject H0")
    }
    
  } else if (alternative == "two.sided") {
    # H0: sigma^2 = sigma0^2, Reject if: chi^2_stat falls outside [chi^2_{1-alpha/2, n-1} ; chi^2_{alpha/2, n-1}]
    
    # Lower Critical Value (1 - alpha/2 percentile)
    crit_val_L <- qchisq(alpha / 2, df = df) 
    # Upper Critical Value (alpha/2 right tail)
    crit_val_R <- qchisq(alpha / 2, df = df, lower.tail = FALSE)
    
    if (chi2_stat < crit_val_L || chi2_stat > crit_val_R) {
      return("Reject H0 (Test Statistic is outside the critical region)")
    } else {
      return("Fail to Reject H0")
    }
    
  } else {
    stop("Invalid 'alternative'. Use 'less', 'greater', or 'two.sided'.")
  }
}

# Hypothesis test for proportions : 
proportionCriticalRegionTest <- function(x, n, p0, alpha, alternative = "two.sided") {
  
  p_hat <- x / n
  
  # --- 1. Calculate Z Test Statistic (using p0 in denominator) ---
  # Standard Error under H0: sqrt(p0 * (1-p0) / n)
  se_h0 <- sqrt(p0 * (1 - p0) / n)
  z_stat <- (p_hat - p0) / se_h0
  
  # --- 2. Determine Critical Value(s) and Decision ---
  
  if (alternative == "less") {
    # H0: p >= p0, Reject if: Z_stat < -Z_alpha
    crit_val <- qnorm(alpha, lower.tail = TRUE) # -Z_alpha
    
    if (z_stat < crit_val) {
      decision <- "Reject H0 (Test Statistic < Critical Value)"
    } else {
      decision <- "Fail to Reject H0"
    }
    
  } else if (alternative == "greater") {
    # H0: p <= p0, Reject if: Z_stat > Z_alpha
    crit_val <- qnorm(alpha, lower.tail = FALSE) # Z_alpha
    
    if (z_stat > crit_val) {
      decision <- "Reject H0 (Test Statistic > Critical Value)"
    } else {
      decision <- "Fail to Reject H0"
    }
    
  } else if (alternative == "two.sided") {
    # H0: p = p0, Reject if: |Z_stat| > Z_alpha/2
    crit_val <- qnorm(alpha / 2, lower.tail = FALSE) # Z_alpha/2
    
    if (abs(z_stat) > crit_val) {
      decision <- "Reject H0 (|Test Statistic| > Critical Value)"
    } else {
      decision <- "Fail to Reject H0"
    }
    
  } else {
    stop("Invalid 'alternative'. Use 'less', 'greater', or 'two.sided'.")
  }
  
  return(list(Z_statistic = z_stat, Decision = decision))
}

testVarianceEqualityFTest <- function(x, y, alpha = 0.05, alternative = "two.sided") {
  
  # --- 1. Perform the F-Test using R's built-in function ---
  # This provides the necessary statistic and p-value
  f_test_results <- var.test(x, y, alternative = alternative)
  
  # --- 2. Extract Key Results ---
  F_statistic <- f_test_results$statistic
  num_df <- f_test_results$parameter[1] # Numerator degrees of freedom
  denom_df <- f_test_results$parameter[2] # Denominator degrees of freedom
  p_value <- f_test_results$p.value
  
  # --- 3. Determine the Decision ---
  if (p_value <= alpha) {
    decision <- paste("Reject H0 (p-value <= ", alpha, "). Conclusion: Variances are unequal.", sep="")
  } else {
    decision <- paste("Fail to Reject H0 (p-value > ", alpha, "). Conclusion: No evidence variances are unequal.", sep="")
  }
  
  # --- 4. Return Summary ---
  summary <- list(
    Hypotheses = paste("H0: sigma1^2 = sigma2^2 vs. H1: sigma1^2 ", 
                       ifelse(alternative == "two.sided", "!=", 
                              ifelse(alternative == "greater", ">", "<")), 
                       " sigma2^2", sep=""),
    F_statistic = as.numeric(F_statistic),
    Numerator_df = as.numeric(num_df),
    Denominator_df = as.numeric(denom_df),
    P_value = as.numeric(p_value),
    Alpha_level = alpha,
    Decision = decision
  )
  
  class(summary) <- "htest.variance"
  return(summary)
}

# Hypothesis test for the equality of means 

testMeanEqualityTTest <- function(x, y, alpha = 0.05, alternative = "two.sided", equal_variance = FALSE) {
  
  # --- 1. Perform the T-Test ---
  # The t.test function handles the core calculations
  t_test_results <- t.test(x, y, 
                           alternative = alternative, 
                           var.equal = equal_variance)
  
  # --- 2. Extract Key Results ---
  t_statistic <- t_test_results$statistic
  df <- t_test_results$parameter # Degrees of freedom
  p_value <- t_test_results$p.value
  
  # Determine the test type for the summary
  test_type <- ifelse(equal_variance, "Student's Two-Sample T-Test (Assumed Equal Variances)", 
                      "Welch's Two-Sample T-Test (Did Not Assume Equal Variances)")
  
  # --- 3. Determine the Decision ---
  if (p_value <= alpha) {
    decision <- paste("Reject H0 (p-value <= ", alpha, "). Conclusion: The means are significantly different.", sep="")
  } else {
    decision <- paste("Fail to Reject H0 (p-value > ", alpha, "). Conclusion: No evidence the means are different.", sep="")
  }
  
  # --- 4. Return Summary ---
  summary <- list(
    Test_Type = test_type,
    Hypotheses = paste("H0: mu1 = mu2 vs. H1: mu1 ", 
                       ifelse(alternative == "two.sided", "!=", 
                              ifelse(alternative == "greater", ">", "<")), 
                       " mu2", sep=""),
    T_statistic = as.numeric(t_statistic),
    Degrees_of_Freedom = as.numeric(df),
    P_value = as.numeric(p_value),
    Alpha_level = alpha,
    Decision = decision
  )
  
  class(summary) <- "htest.mean"
  return(summary)
}

testProportionEquality <- function(x, n, alpha = 0.05, alternative = "two.sided", correct = FALSE) {
  
  # Input validation
  if (length(x) != 2 || length(n) != 2) {
    stop("Both 'x' (successes) and 'n' (trials) must be vectors of length 2.")
  }
  if (any(x > n)) {
    stop("The number of successes (x) cannot be greater than the number of trials (n).")
  }
  
  # --- 1. Perform the Proportion Test ---
  # prop.test is the standard way to compare two proportions
  prop_test_results <- prop.test(x = x, 
                                 n = n, 
                                 alternative = alternative, 
                                 correct = correct)
  
  # --- 2. Extract Key Results ---
  prop_hats <- x / n # Sample proportions
  chi2_statistic <- prop_test_results$statistic
  df <- prop_test_results$parameter
  p_value <- prop_test_results$p.value
  
  # --- 3. Determine the Decision ---
  if (p_value <= alpha) {
    decision <- paste("Reject H0 (p-value <= ", alpha, "). Conclusion: The population proportions are significantly different.", sep="")
  } else {
    decision <- paste("Fail to Reject H0 (p-value > ", alpha, "). Conclusion: No evidence the population proportions are different.", sep="")
  }
  
  # --- 4. Return Summary ---
  summary <- list(
    Test_Type = "Two-Sample Proportion Test (Chi-Squared/Z-Test)",
    Hypotheses = paste("H0: p1 = p2 vs. H1: p1 ", 
                       ifelse(alternative == "two.sided", "!=", 
                              ifelse(alternative == "greater", ">", "<")), 
                       " p2", sep=""),
    Sample_Proportions = setNames(as.numeric(prop_hats), c("p1_hat", "p2_hat")),
    Chi2_statistic = as.numeric(chi2_statistic),
    Degrees_of_Freedom = as.numeric(df),
    P_value = as.numeric(p_value),
    Alpha_level = alpha,
    Decision = decision
  )
  
  class(summary) <- "htest.proportion"
  return(summary)
}


# goodness of fit 

testGoodnessOfFit <- function(x, p,  estimated_params = 0,alpha = 0.05) {
  
  # --- A. Modification 1: Add new argument ---
  # 'estimated_params' tracks how many parameters (mu, sigma, lambda, p) 
  # were estimated from the data.
  
  # Input validation
  num_categories <- length(x)
  if (num_categories <= (1 + estimated_params)) {
    stop("The number of categories must be greater than (1 + estimated_params). Corrected DF would be <= 0.")
  }
  if (abs(sum(p) - 1) > 1e-6) {
    p <- p / sum(p) # Ensure expected probabilities sum to 1
  }
  
  # --- B. Modification 2: Calculate Statistic Manually ---
  # We use the explicit formula for the Chi-Squared statistic: sum((O_i - E_i)^2 / E_i)
  
  E_i <- sum(x) * p
  chi2_statistic <- sum((x - E_i)^2 / E_i)
  
  # --- C. Modification 3: Calculate Corrected Degrees of Freedom ---
  
  # DF = (Number of categories) - 1 - (Number of estimated parameters)
  corrected_df <- num_categories - 1 - estimated_params
  
  # --- D. Modification 4: Calculate P-Value with Corrected DF ---
  
  # pchisq(q, df, lower.tail=FALSE) gives the area in the right tail (the P-value)
  p_value <- pchisq(chi2_statistic, df = corrected_df, lower.tail = FALSE)
  
  # --- 3. Determine the Decision (Uses the corrected P-value) ---
  if (p_value <= alpha) {
    decision <- paste("Reject H0 (p-value <= ", alpha, "). Conclusion: The distribution does NOT fit the expected probabilities.", sep="")
  } else {
    decision <- paste("Fail to Reject H0 (p-value > ", alpha, "). Conclusion: The distribution fits the expected probabilities.", sep="")
  }
  
  # --- E. Modification 5: Update Summary Output ---
  summary <- list(
    Test_Type = "Chi-Squared Goodness-of-Fit Test (DF Corrected)",
    Hypotheses = "H0: Observed distribution = Expected distribution vs. H1: Distributions are different",
    Chi2_statistic = as.numeric(chi2_statistic),
    # Show the corrected degrees of freedom:
    Degrees_of_Freedom = as.numeric(corrected_df), 
    P_value = as.numeric(p_value),
    Alpha_level = alpha,
    Decision = decision
  )
  
  class(summary) <- "htest.chisq"
  return(summary)
}


testIndependence <- function(table, alpha = 0.05) {
  
  # Input validation
  if (!is.matrix(table) && !is.data.frame(table)) {
    stop("Input 'table' must be a matrix or data frame (contingency table).")
  }
  
  # Ensure the table is a matrix for the test
  if (!is.matrix(table)) {
    table <- as.matrix(table)
  }
  
  # --- 1. Perform the Chi-Squared Test ---
  # chisq.test calculates the observed, expected, statistic, and p-value.
  independence_test_results <- chisq.test(x = table)
  
  # --- 2. Extract Key Results ---
  chi2_statistic <- independence_test_results$statistic
  df <- independence_test_results$parameter
  p_value <- independence_test_results$p.value
  
  # --- NEW: Extract Expected Frequencies Matrix ---
  expected_freqs_matrix <- independence_test_results$expected
  
  # --- 3. Determine the Decision ---
  if (p_value <= alpha) {
    decision <- paste("Reject H0 (p-value <= ", alpha, "). Conclusion: The variables are DEPENDENT (related).", sep="")
  } else {
    decision <- paste("Fail to Reject H0 (p-value > ", alpha, "). Conclusion: The variables are INDEPENDENT (not related).", sep="")
  }
  
  # --- 4. Return Summary ---
  summary <- list(
    Test_Type = "Chi-Squared Test of Independence",
    Hypotheses = "H0: Variables are independent vs. H1: Variables are dependent (related)",
    Chi2_statistic = as.numeric(chi2_statistic),
    Degrees_of_Freedom = as.numeric(df),
    P_value = as.numeric(p_value),
    Alpha_level = alpha,
    Decision = decision,
    # --- NEW: Include the Expected Frequencies Matrix ---
    Expected_Frequencies_Eij = expected_freqs_matrix
  )
  
  class(summary) <- "htest.chisq"
  return(summary)
}

# fitting functions 
getPoissonExpectedFreqs <- function(data) {
  
  # 1. Estimate Parameter and Total N
  N <- length(data)
  lambda_hat <- mean(data) # MLE for Poisson lambda is the sample mean
  
  # 2. Prepare Observed Frequencies
  obs_table <- table(data)
  k_levels <- as.numeric(names(obs_table))
  observed_freqs <- as.numeric(obs_table)
  
  # 3. Calculate Expected Probabilities and Frequencies
  # dpois() is the Poisson Probability Mass Function (PMF)
  expected_probabilities <- dpois(k_levels, lambda = lambda_hat)
  expected_freqs <- N * expected_probabilities
  
  # 4. Return Results
  results_df <- data.frame(
    k_Count = k_levels,
    Observed_Freq_Oi = observed_freqs,
    Expected_Freq_Ei = expected_freqs
  )
  
  return(results_df)
}

getBinomialFxpectedFreqs <- function(data, size) {
  
  # 1. Estimate Parameter and Total N
  N <- length(data)
  # MLE for Binomial p is the sample mean / size
  p_hat <- mean(data) / size 
  
  # 2. Prepare Observed Frequencies
  obs_table <- table(data)
  k_levels <- as.numeric(names(obs_table))
  observed_freqs <- as.numeric(obs_table)
  
  # 3. Calculate Expected Probabilities and Frequencies
  # dbinom() is the Binomial Probability Mass Function (PMF)
  expected_probabilities <- dbinom(k_levels, size = size, prob = p_hat)
  expected_freqs <- N * expected_probabilities
  
  # 4. Return Results
  results_df <- data.frame(
    k_Successes = k_levels,
    Observed_Freq_Oi = observed_freqs,
    Expected_Freq_Ei = expected_freqs
  )
  
  return(results_df)
}

getNormalExpectedFreqs <- function(data, breaks) {
  
  # 1. Estimate Parameters and Total N
  N <- length(data)
  mu_hat <- mean(data)      # MLE for Normal mean is the sample mean
  sigma_hat <- sd(data)    # MLE for Normal std dev is the sample standard deviation
  
  # 2. Prepare Observed Frequencies (using R's cut and table)
  observed_counts <- table(cut(data, breaks = breaks, right = FALSE, include.lowest = TRUE))
  observed_freqs <- as.numeric(observed_counts)
  
  # 3. Calculate Expected Probabilities and Frequencies
  
  # Calculate cumulative probability (pnorm) for each break point
  p_cumulative <- pnorm(breaks, mean = mu_hat, sd = sigma_hat)
  
  # Probability for each bin is the difference between cumulative probabilities
  # Example: P(a < X <= b) = P(X <= b) - P(X <= a)
  expected_probabilities <- diff(p_cumulative)
  
  # Calculate Expected Frequencies (Ei = N * Pi)
  expected_freqs <- N * expected_probabilities
  
  # 4. Return Results
  # Prepare interval labels for clarity
  bin_intervals <- levels(cut(data, breaks = breaks, right = FALSE, include.lowest = TRUE))
  
  results_df <- data.frame(
    Bin_Intervals = bin_intervals,
    Observed_Freq_Oi = observed_freqs,
    Expected_Freq_Ei = expected_freqs
  )
  
  return(results_df)
}

getNormalExpectedFreqsFromGrouped <- function(frequencies, breaks) {
  
  # Input validation
  if (length(frequencies) != (length(breaks) - 1)) {
    stop("The number of frequencies must be one less than the number of breaks.")
  }
  
  # --- 1. Calculate Midpoints and Estimate Parameters ---
  
  N <- sum(frequencies) # Total sample size
  
  # Calculate Midpoints (m_i) for each interval
  midpoints <- (breaks[-length(breaks)] + breaks[-1]) / 2
  
  # Estimate Mean (mu_hat) from grouped data
  mu_hat <- sum(midpoints * frequencies) / N
  
  # Estimate Standard Deviation (sigma_hat) from grouped data (using N in denominator)
  sum_sq_diff_f <- sum(((midpoints - mu_hat)^2) * frequencies)
  sigma_hat <- sqrt(sum_sq_diff_f / N)
  
  # --- 2. Calculate Expected Probabilities and Frequencies ---
  
  # Calculate cumulative probability (pnorm) for each break point
  p_cumulative <- pnorm(breaks, mean = mu_hat, sd = sigma_hat)
  
  # Probability for each bin (Pi = difference between cumulative probabilities)
  expected_probabilities <- diff(p_cumulative)
  
  # Expected Frequency (Ei = N * Pi)
  expected_freqs <- N * expected_probabilities
  
  # --- 3. Return Results ---
  
  # Create interval labels for the output table
  bin_intervals <- paste0(breaks[-length(breaks)], "-", breaks[-1])
  
  results_df <- data.frame(
    Bin_Intervals = bin_intervals,
    Observed_Freq_Oi = frequencies,
    Expected_Freq_Ei = expected_freqs,
    Estimated_Mean = mu_hat,
    Estimated_SD = sigma_hat
  )
  
  return(results_df)
}
getNormalExpectedFreqsFromGrouped <- function(frequencies, breaks) {
  
  # Input validation
  if (length(frequencies) != (length(breaks) - 1)) {
    stop("The number of frequencies must be one less than the number of breaks.")
  }
  
  # --- 1. Calculate Midpoints and Estimate Parameters ---
  
  N <- sum(frequencies) # Total sample size
  
  # Calculate Midpoints (m_i) for each interval
  midpoints <- (breaks[-length(breaks)] + breaks[-1]) / 2
  
  # Estimate Mean (mu_hat) from grouped data
  mu_hat <- sum(midpoints * frequencies) / N
  
  # Estimate Standard Deviation (sigma_hat) from grouped data (using N in denominator)
  sum_sq_diff_f <- sum(((midpoints - mu_hat)^2) * frequencies)
  sigma_hat <- sqrt(sum_sq_diff_f / N)
  
  # --- 2. Calculate Expected Probabilities and Frequencies ---
  
  # Calculate cumulative probability (pnorm) for each break point
  p_cumulative <- pnorm(breaks, mean = mu_hat, sd = sigma_hat)
  
  # Probability for each bin (Pi = difference between cumulative probabilities)
  expected_probabilities <- diff(p_cumulative)
  
  # Expected Frequency (Ei = N * Pi)
  expected_freqs <- N * expected_probabilities
  
  # --- 3. Return Results ---
  
  # Create interval labels for the output table
  bin_intervals <- paste0(breaks[-length(breaks)], "-", breaks[-1])
  
  results_df <- data.frame(
    Bin_Intervals = bin_intervals,
    Observed_Freq_Oi = frequencies,
    Expected_Freq_Ei = expected_freqs,
    Estimated_Mean = mu_hat,
    Estimated_SD = sigma_hat
  )
  
  return(results_df)
}

getBinomialExpectedFreqsFromGrouped <- function(k_successes, frequencies, size) {
  
  if (length(k_successes) != length(frequencies)) {
    stop("The success levels and frequencies must be of the same length.")
  }
  
  # 1. Estimate Parameter and Total N
  N <- sum(frequencies)
  
  # Average number of successes per experiment
  average_successes <- sum(k_successes * frequencies) / N
  
  # MLE for Binomial p is (average successes) / size
  p_hat <- average_successes / size 
  
  # 2. Calculate Expected Probabilities and Frequencies
  # dbinom() is the Binomial PMF
  expected_probabilities <- dbinom(k_successes, size = size, prob = p_hat)
  expected_freqs <- N * expected_probabilities
  
  # 3. Return Results
  results_df <- data.frame(
    k_Successes = k_successes,
    Observed_Freq_Oi = frequencies,
    Expected_Freq_Ei = expected_freqs
  )
  
  return(results_df)
}

getPoissonExpectedFreqsGrouped <- function(k_counts, observed_freqs) {
  
  # Input validation
  if (length(k_counts) != length(observed_freqs)) {
    stop("k_counts and observed_freqs must have the same length.")
  }
  
  k_counts <- as.numeric(k_counts)
  observed_freqs <- as.numeric(observed_freqs)
  
  # 1. Estimate Parameter and Total N for Grouped Data
  
  # Total N is the sum of the observed frequencies (total number of observations)
  N <- sum(observed_freqs)
  
  # The mean (lambda_hat) is the sum of (k * frequency) / N
  # E(X) = (sum(k_i * f_i)) / N
  lambda_hat <- sum(k_counts * observed_freqs) / N
  
  # 2. Prepare Results Structure (already done by input)
  # The input k_counts and observed_freqs define the groups.
  
  # 3. Calculate Expected Probabilities and Frequencies
  # dpois() is the Poisson Probability Mass Function (PMF)
  expected_probabilities <- dpois(k_counts, lambda = lambda_hat)
  expected_freqs <- N * expected_probabilities
  
  # 4. Return Results
  results_df <- data.frame(
    k_Count = k_counts,
    Observed_Freq_Oi = observed_freqs,
    Expected_Freq_Ei = expected_freqs
  )
  
  cat(sprintf("--- Estimation Summary ---\n"))
  cat(sprintf("Total Observations (N): %d\n", N))
  cat(sprintf("Estimated Lambda (λ̂): %.4f\n", lambda_hat))
  cat(sprintf("--------------------------\n"))
  
  return(results_df)
}





